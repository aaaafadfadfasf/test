#include "demomsgmanage.h"

CImRegReq::CImRegReq()
{
    event = OspExtEventDesc(IM_C_S_REG_REQ);
}
const std::string CImRegReq::ToXml()const
{
	TiXmlElement xmlNode("CImRegReq");
	ToXmlWithoutClassNameNode(xmlNode);
	TiXmlPrinter printer;
	printer.SetStreamPrinting();
	xmlNode.Accept(&printer);
	return printer.Str();
}

void CImRegReq::ToXml(TiXmlDocument& xmlDoc)const
{
	TiXmlElement* pclass_nameNode = new TiXmlElement("CImRegReq");
	xmlDoc.LinkEndChild(pclass_nameNode);
	ToXmlWithoutClassNameNode(*pclass_nameNode);
}

void CImRegReq::ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const
{
	CEventReq::ToXmlWithoutClassNameNode(xmlNode);

	ConvertHelper::ToXml::AddChildNode(xmlNode, "userName", "string", m_strUserName);
	ConvertHelper::ToXml::AddChildNode(xmlNode, "passWord", "string", m_strPassWord);
	ConvertHelper::ToXml::AddChildNode(xmlNode, "devUri", "string", m_strDevUri);

}
void CImRegReq::FromXml(const std::string& xml_string)
{
	TiXmlDocument xmlNode;
	xmlNode.Parse(xml_string.c_str());

	TiXmlNode* pRoot = xmlNode.RootElement();
	if (!pRoot)
	{
		return;
	}
	FromXml(*pRoot);
}
void CImRegReq::FromXml(const TiXmlNode& xmlNode)
{
	*this = CImRegReq();

    if (xmlNode.ValueStr() == "CImRegReq")
	{
		return;
	}
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "userName", m_strUserName);
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "passWord", m_strPassWord);
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "devUri", m_strDevUri);
}


CImCheckOutRsp::CImCheckOutRsp()
{
    event = OspExtEventDesc(IM_S_C_CHECK_ONLINE_RSP);
}
const std::string CImCheckOutRsp::ToXml()const
{
	TiXmlElement xmlNode("CImCheckOutRsp");
	ToXmlWithoutClassNameNode(xmlNode);
	TiXmlPrinter printer;
	printer.SetStreamPrinting();
	xmlNode.Accept(&printer);
	return printer.Str();
}

void CImCheckOutRsp::ToXml(TiXmlDocument& xmlDoc)const
{
	TiXmlElement* pclass_nameNode = new TiXmlElement("CImCheckOutRsp");
	xmlDoc.LinkEndChild(pclass_nameNode);
	ToXmlWithoutClassNameNode(*pclass_nameNode);
}

void CImCheckOutRsp::ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const
{
	CEventRsp::ToXmlWithoutClassNameNode(xmlNode);

	ConvertHelper::ToXml::AddChildNode(xmlNode, "info", "string", m_strOnlineUserInfo);
}
void CImCheckOutRsp::FromXml(const std::string& xml_string)
{
	TiXmlDocument xmlNode;
	xmlNode.Parse(xml_string.c_str());

	TiXmlNode* pRoot = xmlNode.RootElement();
	if (!pRoot)
	{
		return;
	}
	FromXml(*pRoot);
}
void CImCheckOutRsp::FromXml(const TiXmlNode& xmlNode)
{
	*this = CImCheckOutRsp();

    if (xmlNode.ValueStr() == "CImCheckOutRsp")
	{
		return;
	}
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "info", m_strOnlineUserInfo);

}

CImLoginReq::CImLoginReq()
{
    event = OspExtEventDesc(IM_C_S_LOGIN_REQ);
}
const std::string CImLoginReq::ToXml()const
{
	TiXmlElement xmlNode("CImLoginReq");
	ToXmlWithoutClassNameNode(xmlNode);
	TiXmlPrinter printer;
	printer.SetStreamPrinting();
	xmlNode.Accept(&printer);
	return printer.Str();
}

void CImLoginReq::ToXml(TiXmlDocument& xmlDoc)const
{
	TiXmlElement* pclass_nameNode = new TiXmlElement("CImLoginReq");
	xmlDoc.LinkEndChild(pclass_nameNode);
	ToXmlWithoutClassNameNode(*pclass_nameNode);
}

void CImLoginReq::ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const
{
	CEventReq::ToXmlWithoutClassNameNode(xmlNode);

	ConvertHelper::ToXml::AddChildNode(xmlNode, "userName", "string", m_strUserName);
	ConvertHelper::ToXml::AddChildNode(xmlNode, "passWord", "string", m_strPassWord);
	ConvertHelper::ToXml::AddChildNode(xmlNode, "devUri", "string", m_strDevUri);

}
void CImLoginReq::FromXml(const std::string& xml_string)
{
	TiXmlDocument xmlNode;
	xmlNode.Parse(xml_string.c_str());

	TiXmlNode* pRoot = xmlNode.RootElement();
	if (!pRoot)
	{
		return;
	}
	FromXml(*pRoot);
}
void CImLoginReq::FromXml(const TiXmlNode& xmlNode)
{
	*this = CImLoginReq();

    if (xmlNode.ValueStr() == "CImLoginReq")
	{
		return;
	}
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "userName", m_strUserName);
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "passWord", m_strPassWord);
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "devUri", m_strDevUri);
}

CImRegRsp::CImRegRsp()
{
    event = OspExtEventDesc(IM_S_C_REG_RSP);
}
CImRegRsp::~CImRegRsp()
{

}
const std::string CImRegRsp::ToXml()const
{
	TiXmlElement xmlNode("CImRegRsp");
	ToXmlWithoutClassNameNode(xmlNode);
	TiXmlPrinter printer;
	printer.SetStreamPrinting();
	xmlNode.Accept(&printer);
	return printer.Str();
}

void CImRegRsp::ToXml(TiXmlDocument& xmlDoc)const
{
	TiXmlElement* pclass_nameNode = new TiXmlElement("CImRegRsp");
	xmlDoc.LinkEndChild(pclass_nameNode);
	ToXmlWithoutClassNameNode(*pclass_nameNode);
}

void CImRegRsp::ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const
{
	CEventRsp::ToXmlWithoutClassNameNode(xmlNode);

	ConvertHelper::ToXml::AddChildNode(xmlNode, "regResultTab", "int", m_nRegResultTab);

}
void CImRegRsp::FromXml(const std::string& xml_string)
{
	TiXmlDocument xmlNode;
	xmlNode.Parse(xml_string.c_str());

	TiXmlNode* pRoot = xmlNode.RootElement();
	if (!pRoot)
	{
		return;
	}
	FromXml(*pRoot);
}
void CImRegRsp::FromXml(const TiXmlNode& xmlNode)
{
	*this = CImRegRsp();

    if (xmlNode.ValueStr() == "CImRegRsp")
	{
		return;
	}
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "regResultTab", m_nRegResultTab);

}

CImMsgReq::CImMsgReq()
{
    event = OspExtEventDesc(IM_C_S_MESSAGE_REQ);
}
CImMsgReq::~CImMsgReq()
{

}

const std::string CImMsgReq::ToXml()const
{
	TiXmlElement xmlNode("CImMsgReq");
	ToXmlWithoutClassNameNode(xmlNode);
	TiXmlPrinter printer;
	printer.SetStreamPrinting();
	xmlNode.Accept(&printer);
	return printer.Str();
}
void CImMsgReq::ToXml(TiXmlDocument& xmlDoc)const
{
	TiXmlElement* pclass_nameNode = new TiXmlElement("CImMsgReq");
	xmlDoc.LinkEndChild(pclass_nameNode);
	ToXmlWithoutClassNameNode(*pclass_nameNode);
}
void CImMsgReq::ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const
{
	CEventReq::ToXmlWithoutClassNameNode(xmlNode);

	ConvertHelper::ToXml::AddChildNode(xmlNode, "dstUser", "string", m_strDstUser);
	ConvertHelper::ToXml::AddChildNode(xmlNode, "sendContent", "string", m_strSendContent);
	ConvertHelper::ToXml::AddChildNode(xmlNode, "devUri", "string", m_strDevUri);
}
void CImMsgReq::FromXml(const std::string& xml_string)
{
	TiXmlDocument xmlNode;
	xmlNode.Parse(xml_string.c_str());

	TiXmlNode* pRoot = xmlNode.RootElement();
	if (!pRoot)
	{
		return;
	}
	FromXml(*pRoot);
}
void CImMsgReq::FromXml(const TiXmlNode& xmlNode)
{
    if (xmlNode.ValueStr() == "CImMsgReq")
	{
		return;
	}
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "dstUser", m_strDstUser);
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "sendContent", m_strSendContent);
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "devUri", m_strDevUri);
}

CImLoginRsp::CImLoginRsp()
{
    event = OspExtEventDesc(IM_S_C_LOGIN_RSP);
}
const std::string CImLoginRsp::ToXml()const
{
	TiXmlElement xmlNode("CImLoginRsp");
	ToXmlWithoutClassNameNode(xmlNode);
	TiXmlPrinter printer;
	printer.SetStreamPrinting();
	xmlNode.Accept(&printer);
	return printer.Str();
}

void CImLoginRsp::ToXml(TiXmlDocument& xmlDoc)const
{
	TiXmlElement* pclass_nameNode = new TiXmlElement("CImLoginRsp");
	xmlDoc.LinkEndChild(pclass_nameNode);
	ToXmlWithoutClassNameNode(*pclass_nameNode);
}

void CImLoginRsp::ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const
{
	CEventRsp::ToXmlWithoutClassNameNode(xmlNode);

	ConvertHelper::ToXml::AddChildNode(xmlNode, "LoginResultTab", "int", m_nLoginResultTab);

}
void CImLoginRsp::FromXml(const std::string& xml_string)
{
	TiXmlDocument xmlNode;
	xmlNode.Parse(xml_string.c_str());

	TiXmlNode* pRoot = xmlNode.RootElement();
	if (!pRoot)
	{
		return;
	}
	FromXml(*pRoot);
}
void CImLoginRsp::FromXml(const TiXmlNode& xmlNode)
{
	*this = CImLoginRsp();

    if (xmlNode.ValueStr() == "CImLoginRsp")
	{
		return;
	}
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "LoginResultTab", m_nLoginResultTab);

}

CImDialogMsgReq::CImDialogMsgReq()
{
    event = OspExtEventDesc(IM_C_S_DIALOG_MESSAGE_REQ);
}
const std::string CImDialogMsgReq::ToXml()const
{
	TiXmlElement xmlNode("CImDialogMsgReq");
	ToXmlWithoutClassNameNode(xmlNode);
	TiXmlPrinter printer;
	printer.SetStreamPrinting();
	xmlNode.Accept(&printer);
	return printer.Str();
}

void CImDialogMsgReq::ToXml(TiXmlDocument& xmlDoc)const
{
	TiXmlElement* pclass_nameNode = new TiXmlElement("CImDialogMsgReq");
	xmlDoc.LinkEndChild(pclass_nameNode);
	ToXmlWithoutClassNameNode(*pclass_nameNode);
}

void CImDialogMsgReq::ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const
{
	CEventReq::ToXmlWithoutClassNameNode(xmlNode);

	ConvertHelper::ToXml::AddChildNode(xmlNode, "dstUser", "string", m_strDstUser);
	ConvertHelper::ToXml::AddChildNode(xmlNode, "sendContent", "string", m_strSendContent);
	ConvertHelper::ToXml::AddChildNode(xmlNode, "devUri", "string", m_strDevUri);
}
void CImDialogMsgReq::FromXml(const std::string& xml_string)
{
	TiXmlDocument xmlNode;
	xmlNode.Parse(xml_string.c_str());

	TiXmlNode* pRoot = xmlNode.RootElement();
	if (!pRoot)
	{
		return;
	}
	FromXml(*pRoot);
}
void CImDialogMsgReq::FromXml(const TiXmlNode& xmlNode)
{
	*this = CImDialogMsgReq();

    if (xmlNode.ValueStr() == "CImDialogMsgReq")
	{
		return;
	}
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "dstUser", m_strDstUser);
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "sendContent", m_strSendContent);
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "devUri", m_strDevUri);
}

CImNtfReq::CImNtfReq()
{
    event = OspExtEventDesc(IM_S_C_NOTIFY_REQ);
}
const std::string CImNtfReq::ToXml()const
{
	TiXmlElement xmlNode("CImNtfReq");
	ToXmlWithoutClassNameNode(xmlNode);
	TiXmlPrinter printer;
	printer.SetStreamPrinting();
	xmlNode.Accept(&printer);
	return printer.Str();
}

void CImNtfReq::ToXml(TiXmlDocument& xmlDoc)const
{
	TiXmlElement* pclass_nameNode = new TiXmlElement("CImNtfReq");
	xmlDoc.LinkEndChild(pclass_nameNode);
	ToXmlWithoutClassNameNode(*pclass_nameNode);
}

void CImNtfReq::ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const
{
	CEventReq::ToXmlWithoutClassNameNode(xmlNode);

	ConvertHelper::ToXml::AddChildNode(xmlNode, "onOffStatus", "string", m_strOnOff);
}
void CImNtfReq::FromXml(const std::string& xml_string)
{
	TiXmlDocument xmlNode;
	xmlNode.Parse(xml_string.c_str());

	TiXmlNode* pRoot = xmlNode.RootElement();
	if (!pRoot)
	{
		return;
	}
	FromXml(*pRoot);
}
void CImNtfReq::FromXml(const TiXmlNode& xmlNode)
{
	*this = CImNtfReq();

    if (xmlNode.ValueStr() == "CImNtfReq")
	{
		return;
	}
	ConvertHelper::ToStruct::ParseChildNode(xmlNode, "LoginResultTab", m_strOnOff);

}
