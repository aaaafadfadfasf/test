#include "imcoreapp.h"

extern CServerApp g_cServerApp;
CImCoreInst::CImCoreInst()
{

}

CImCoreInst::~CImCoreInst()
{

}
void CImCoreInst::DaemonEntry(CMessage *const pcMsg)
{
	switch (pcMsg->event)
	{
	case IM_C_S_REG_REQ:
	case IM_C_S_LOGIN_REQ:
		{
			CTask *pcTask = new CServerTask(this);
            if (pcTask == NULL)
			{
				OspPrintf(TRUE, FALSE, "��������ʧ��!\n");
			}
			pcTask->InitStateMachine();
			pcTask->ProcMsg(pcMsg);
		}
		break;
	default:
		{
			COspSipMsg *pcMonMsg = (COspSipMsg *)pcMsg->content;
			string strSession = GetXmlVal(pcMonMsg->GetMsgBody(), "session");
			PCUerData pcUserData = g_cServerApp.GetAppData().FindUserBySessId(strSession);
            if (pcUserData != NULL)
			{
				pcUserData->ProcMsg(pcMsg);
			}
			else
			{
				OspPrintf(TRUE, FALSE, "û���ҵ���Ӧ��session!\n");
			}
		}
		break;
	}
}


CUserInfos::CUserInfos()
{

}
CUserInfos::~CUserInfos()
{
    m_mapUserDataOnline.Empty();
    m_mapUserSessionOnline.Empty();
}
