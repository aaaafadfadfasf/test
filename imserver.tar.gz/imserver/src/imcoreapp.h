#ifndef _IM_CORE_APP_H
#define _IM_CORE_APP_H

#include "cms/ospext/ospext.h"
#include "cms/ospext/ospinst.h"
#include "cbb/osp/osp.h"
#include "cms/ospext/osplog.h"
#include "cms/ospext/osptool.h"
#include "democonf.h"
#include "servertask.h"

class CServerTask;

typedef CServerTask CUserData;
typedef CUserData  * PCUerData;

class CImCoreInst : public CInstExt
{

public:
	CImCoreInst();
	virtual ~CImCoreInst();

	//��Ϣ���
	virtual void DaemonEntry(CMessage* const pcMsg);
};

class CUserInfos
{
public:
    CUserInfos();
    ~CUserInfos();
public:
    bool AddUser(PCUerData pcUserData)
    {
        if (pcUserData == NULL)
        {
            return false;
        }

       // m_mapUserDataOnline.Insert(pcUserData->GetUserName(), pcUserData);
        //m_mapUserSessionOnline.Insert(pcUserData->GetSessionID(), pcUserData);
        return true;
    }

    PCUerData FindUserInfoByUserName(const string strUserName)
    {
        PCUerData *ppcUserData = m_mapUserDataOnline.Find(strUserName);
        if (ppcUserData)
        {
            return *ppcUserData;
        }
        return NULL;
    }

    PCUerData FindUserBySessId(const string strSessionId)
    {
        PCUerData *ppcUserData = m_mapUserSessionOnline.Find(strSessionId);
        if (ppcUserData)
        {
            return *ppcUserData;
        }
        return NULL;
    }

    void DelUser(PCUerData pcUserData)
    {
        if (pcUserData == NULL)
        {
            return;
        }
        //m_mapUserSessionOnline.Erase(pcUserData->GetSessionID());
        //m_mapUserDataOnline.Erase(pcUserData->GetUserName());
    }

private:
    CStrMap<PCUerData> m_mapUserDataOnline;
    CStrMap<PCUerData> m_mapUserSessionOnline;
};

typedef COspApp<CImCoreInst,64,CUserInfos>  CServerApp;



#endif
