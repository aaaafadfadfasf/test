#include "democonf.h"
#include "ospsip.h"
#include "imcoreapp.h"

CXSemLock g_cMainSemLock;
CServerApp g_cServerApp;
CFastDBInterface *g_redis;
TDevUriDialogId g_tDevUriDialogId;

int main(int argc, char* argv[])
{
	//��ʼ����־�ļ�
	string strLogDir = GetLogDir();
	TOspExtConf tOspExtConf;
	tOspExtConf.strErrLogDir = strLogDir + "im\\errorlog\\";
	tOspExtConf.strRunLogDir = strLogDir + "im\\runlog";

    InitEventDesc();

	//��ʼ��OSPEXT
	tOspExtConf.ReadKeyCfg(CONF_FILE_PATH);
	if (FALSE == OspExtInit(tOspExtConf))
	{
		OspPrintf(TRUE,FALSE,"ospext��ʼ��ʧ��\n");
		return 0;
	}
	OspPrintf(TRUE,FALSE,"ospext��ʼ���ɹ�!\n");

	//��ʼ��Redis
	g_redis = new CFastDBInterface();
	FDB_ConnInfo connectInfo;
	connectInfo.clientname = CLIENT_NAME;
	connectInfo.password = DEMO_REDIS_PASSWORD;
	g_redis->Connect(DEMO_REDIS_SERVER, DEMO_REDIS_PORT, connectInfo);
	g_redis->SelectDB(DEMO_REDIS_ID);

	//��ʼ��Sip
	TOspSipConf tOspSipConf;
	tOspSipConf.tLocalAddr.tIpAddr = DEMO_SERVER_LOCAL_IP;
	tOspSipConf.tLocalAddr.wPort   = DEMO_SERVER_LOCAL_PORT;
	tOspSipConf.tProxyAddr.tIpAddr = DEMO_PROXY_IP;
	tOspSipConf.tProxyAddr.wPort   = DEMO_PROXY_PORT;
	tOspSipConf.tLocalURI.SetNOString(DEMO_SERVER_URI);
	tOspSipConf.dwDefaultOspIID = MAKEIID(DEMO_SERVER_AID, CInstance::DAEMON);

	g_cServerApp.CreateOspApp("DemoServer", IM_CORE_APP_ID, 80);

	TSipStackConf tSipStackConf;
	if (!OspSipInit(tOspSipConf, tSipStackConf))
	{
		printf("InitOspSip fail!!!\n");
		return 0;
	}
	OspPrintf(TRUE,FALSE,"Sip ��ʼ���ɹ�!\n");

    bool bRegProxy = OspSipRegProxy(180);
	if (!bRegProxy)
	{
		printf("OspSipRegProxy[%s] fail!!!\n", tOspSipConf.tProxyAddr.GetSipAddrStr().c_str());
		return 0;
	}

	OspPrintf(TRUE,FALSE,"OspSipע��proxy[%s]�ɹ�!\n", tOspSipConf.tProxyAddr.GetSipAddrStr().c_str());

	g_cMainSemLock.Lock();
	g_cMainSemLock.Lock();
	OspSipQuit();
	OspQuit();
	return 0;

}
