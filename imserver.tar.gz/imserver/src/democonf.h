#ifndef _DEMO_CONF_H
#define _DEMO_CONF_H

#include "cms/commonconfig/cmcfg.h"
#include "sdk/fastdbsdk/fastdb.h"
#include "cms/ospext/osptool.h"
#include "kdvtype.h"
#include "kdvsys.h"
#include "ospsip.h"

#define SECTION_IM              ( "IM" )
#define KEY_LOCAL_IP            ( "LocalIP" )         //����SIP��ַ
#define KEY_LOCAL_PORT          ( "LocalPort" )       //����SIP�˿�

#define MAX_READ_CONF_NUM       64
#define DEAFULT_LOCAL_PORT      9080

#define CONF_FILE_PATH          "im.ini"

#define IM_CORE_APP_ID         156
#define IM_CORE_DAEMON         (MAKEIID(IM_CORE_APP_ID, CInstance::DAEMON))
#define IM_CORE_APP_QUEUE_SIZE 10000

#define EVENT_CODE_START       5000
#define CLIENT_NAME            "demo_redis"
#define DEMO_REDIS_ID          2
#define REG_INFO_SET           "reg_info"
#define ONLINE_INFO  		   "online_info"
#define ON_OFF_SUB_TYPE        "on_off_sub_type" //��������

#define DEMO_SERVER_AID         506
#define DEMO_SERVER_LOCAL_PORT  9080
#define DEMO_SERVER_URI         ("server@demo")
#define DEMO_PROXY_IP           ("172.16.65.107")
#define DEMO_SERVER_LOCAL_IP    ("172.16.65.107")
#define DEMO_PROXY_PORT         9081

using namespace std;

const string DEMO_REDIS_PASSWORD = "kedacom";
const string DEMO_REDIS_SERVER = "127.0.0.1";
const int    DEMO_REDIS_PORT = 6379;

void InitEventDesc();

enum EDemoEventCode
{

    IM_C_S_REG_REQ = EVENT_CODE_START,    //ע����Ϣ
    IM_S_C_REG_RSP,

    IM_C_S_LOGIN_REQ,					   //��½��Ϣ
    IM_S_C_LOGIN_RSP,

	IM_C_S_CHECK_ONLINE_REQ,			   //�鿴��ǰ�����û���Ϣ
	IM_S_C_CHECK_ONLINE_RSP,

	IM_C_S_SUB_REQ,						  //������Ϣ
	IM_S_C_SUB_RSP,

	IM_C_S_UN_SUB_REQ,					  //ȡ������
	IM_S_C_UM_SUB_RSP,

	IM_S_C_NOTIFY_REQ,					  //֪ͨ��Ϣ
	IM_C_S_NOTIFY_RSP,

	IM_C_S_INVITE_REQ,					  //����Ự��Ϣ
	IM_S_C_INVITE_RSP,
	IM_C_S_INVITE_ACK,						

	IM_C_S_MESSAGE_REQ,					  //��Ϣת��
	IM_S_C_MESSAGE_RSP,

	IM_C_S_INVITE_BYE_REQ,				  //�����Ự��Ϣ
	IM_S_C_INVITE_BYE_RSP,

	IM_C_S_DIALOG_MESSAGE_REQ,			  //�Ự����Ϣ
	IM_S_C_DIALOG_MESSAGE_RSP,

	IM_S_C_DIALOG_MESSAGE_REQ,
    IM_C_S_DIALOG_MESSAGE_RSP
};

//����demo���̵Ĵ������
enum EDemoErrCode
{
	DEMO_SUCCESS = 0,			      //����һ���ɹ�����

	//����������
	ERR_SIP_BODY_EMPTY,
	ERR_REDIS_OPERATE_FAILED,
	ERR_USER_LOGIN_FAILED,
	ERR_UNINVITE,
	ERR_USER_IS_EXIST,
};

//������־��� server��1  client��2
enum EDemoModule
{
	DEMO_SERVER = 1,				  
	DEMO_CLIENT,
};


#endif
