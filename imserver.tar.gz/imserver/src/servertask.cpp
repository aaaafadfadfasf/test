#include "servertask.h"

extern CFastDBInterface *g_redis;
extern TDevUriDialogId g_tDevUriDialogId;
extern CServerApp g_cServerApp;
CServerTask::CServerTask(CInstExt *pcInst) : CSipTask(pcInst)
{

}
CServerTask::~CServerTask()
{

}

void CServerTask::InitStateMachine()
{
	CStateProc cWaitLoginProc;
	cWaitLoginProc.ProcMsg = (CTask::PFProcMsg)&CServerTask::OnWaitLogin;
	cWaitLoginProc.ProcErrMsg = (CTask::PFProcMsg)&CServerTask::OnWaitLogin;
	AddRuleProc(UnService, cWaitLoginProc);

	CStateProc cWaitServiceProc;
	cWaitServiceProc.ProcMsg = (CTask::PFProcMsg)&CServerTask::OnService;
	cWaitServiceProc.ProcErrMsg = (CTask::PFProcMsg)&CServerTask::OnService;
	AddRuleProc(Service, cWaitServiceProc);

	NextState(UnService);
}


u32 CServerTask::OnWaitLogin(CMessage *const pcMsg)
{
	u32 dProcResult = PROCMSG_FAIL;

	int dwErrorCode = DEMO_SUCCESS;
	COspSipMsg* pcOspSipMsg = (COspSipMsg*)pcMsg->content;
    if (pcOspSipMsg == NULL)
	{
		TASKLOG(DEMO_SERVER, ERROR_LEV, "OSP SIP ��ϢΪ��!\n");
		dwErrorCode = ERR_SIP_BODY_EMPTY;
		dProcResult = PROCMSG_DEL;
		return dProcResult;
	}
	switch (pcMsg->event)
	{
	case IM_C_S_REG_REQ:
		{
			CImRegReq cReq;
			pcOspSipMsg->GetMsgBody(cReq);

			/*��ע����Ϣ��DevUri������redis������֤�Ƿ���ע��*/
			if (EC_NOT_EXISTED == g_redis->IsKeyExists(cReq.GetUserName()))
			{
				g_redis->Set(cReq.GetUserName(), cReq.GetPassWord());
			}
			else
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "ע����Ϣ%sʧ��", cReq.GetUserName().c_str());
				dwErrorCode = ERR_REDIS_OPERATE_FAILED;
			}

			CImRegRsp cRsp;
			cRsp.SetErrorCode(dwErrorCode);
            cRsp.SetSeqNum(cReq.GetSeqNum());
			cRsp.SetRegResultTab(dwErrorCode);
			PostMsgRsp(pcOspSipMsg->GetSipTransID(), cRsp);

			if (dwErrorCode == DEMO_SUCCESS)
			{
				TASKLOG(DEMO_SERVER, CRITICAL_LEV, "%sע��ɹ�!\n", cReq.GetUserName().c_str());
				dProcResult = PROCMSG_OK;
				NextState(UnService);
			}
			else
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "%sע��ʧ��!\n", cReq.GetUserName().c_str());
				dProcResult = PROCMSG_DEL;
			}
		}
		break;
	case IM_C_S_LOGIN_REQ:
		{
			CImLoginReq cReq;
			pcOspSipMsg->GetMsgBody(cReq);

			/*��redis���ҵ�ע����Ϣ����֤�Ƿ�ע��,����redis�б�ʶ���û�����*/
			string strPasswd;
			int n_ErrCode = g_redis->Get(cReq.GetUserName(), strPasswd);
			if (n_ErrCode == EC_NOT_EXISTED)
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "��redis��δ���ҵ�%s��ע����Ϣ! ErrCode = %d\n", cReq.GetUserName().c_str(), n_ErrCode);
				dwErrorCode = ERR_REDIS_OPERATE_FAILED;
			}
			if (strPasswd != cReq.GetPassWord())
			{
				dwErrorCode = ERR_USER_LOGIN_FAILED;
				TASKLOG(DEMO_SERVER, ERROR_LEV, "%s�û���½ʧ��", cReq.GetUserName().c_str());
			}
			else
			{
				g_redis->SAdd(ONLINE_INFO, cReq.GetUserName());
			}

			/*����uuid��Ϊsession,������ʶѰ��taskָ��*/
            CUserData *pcUserData = NULL;
            if (g_cServerApp.GetAppData().FindUserInfoByUserName(cReq.GetUserName()) != NULL)
			{
				dwErrorCode = ERR_USER_IS_EXIST;
				TASKLOG(DEMO_SERVER, ERROR_LEV, "�û� %s ������\n", cReq.GetUserName().c_str());
			}
			else
			{
				pcUserData = this;
				CUUID cSessionId;
				pcUserData->SetSessionID(cSessionId);
				g_cServerApp.GetAppData().AddUser(pcUserData);

				//��ʼ����
				SetHBParam(cReq.GetDevUri());
			}

			CImLoginRsp cRsp;
			cRsp.SetErrorCode(dwErrorCode);
            cRsp.SetSeqNum(cReq.GetSeqNum());
			cRsp.SetSession(pcUserData->GetSessionID());
			cRsp.SetLoginResultTab(n_ErrCode);
			PostMsgRsp(pcOspSipMsg->GetSipTransID(), cRsp);

			if (dwErrorCode == DEMO_SUCCESS)
			{
				TASKLOG(DEMO_SERVER, CRITICAL_LEV, "%s��½�ɹ�!\n", cReq.GetUserName().c_str());
				dProcResult = PROCMSG_OK;
				NextState(Service);
			}
			else
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "%��½ʧ��!\n", cReq.GetUserName().c_str());
				dProcResult = PROCMSG_DEL;
			}
		}
		break;
	default:
		break;
	}
	return dProcResult;
}

u32 CServerTask::OnService(CMessage *const pcMsg)
{
	u32 dProcResult = PROCMSG_FAIL;

	int dwErrorCode = DEMO_SUCCESS;
	COspSipMsg* pcOspSipMsg = (COspSipMsg*)pcMsg->content;
    if (pcOspSipMsg == NULL)
	{
		TASKLOG(DEMO_SERVER, ERROR_LEV, "OSP SIP ��ϢΪ��!\n");
		dwErrorCode = ERR_SIP_BODY_EMPTY;
		dProcResult = PROCMSG_DEL;
		return dProcResult;
	}

	switch (pcMsg->event)
	{
	case IM_C_S_CHECK_ONLINE_REQ:
		{
            CEventReq cReq;
			pcOspSipMsg->GetMsgBody(cReq);

			/*��redis�л�ȡ��ǰ�����û�*/
			vector<string> vecOnlineInfo;
			g_redis->SMembers(ONLINE_INFO, vecOnlineInfo);
			string strOnlineInfo = OrganizeOnlineInfo(vecOnlineInfo);

			CImCheckOutRsp cRsp;
			cRsp.SetErrorCode(dwErrorCode);
            cRsp.SetSeqNum(cReq.GetSeqNum());
			cRsp.SetSession(cReq.GetSession());
			cRsp.SetOnlineUserInfo(strOnlineInfo);
			PostMsgRsp(pcOspSipMsg->GetSipTransID(), cRsp);

			if (dwErrorCode == DEMO_SUCCESS)
			{
				TASKLOG(DEMO_SERVER, CRITICAL_LEV, "��ȡ��ǰ�����û���Ϣ�ɹ�!\n");
				dProcResult = PROCMSG_OK;
			}
			else
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "��ȡ��ǰ�����û���Ϣʧ��!\n");
				dProcResult = PROCMSG_DEL;
			}
		}
		break;
	case IM_C_S_INVITE_REQ:
		{
			CEventReq cReq;
			pcOspSipMsg->GetMsgBody(cReq);

			CEventRsp cRsp;
			cRsp.SetSession(cReq.GetSession());
			cRsp.SetErrorCode(dwErrorCode);
			cRsp.SetEvent("IM_S_C_INVITE_RSP");
            cRsp.SetSeqNum(cReq.GetSeqNum());

			PostRsp(KDSIP_EVENT_INVITE_RSP, pcOspSipMsg->GetSipTransID(), cRsp);
			TASKLOG(DEMO_SERVER,EVENT_LEV, "����Invite Rsp�ɹ�!\n");
			dProcResult = PROCMSG_OK;
		}
		break;
	case IM_C_S_INVITE_ACK:
		{
			CImMsgReq cReq;
			TKDSIP_DIALOG_ID tDialogId = pcOspSipMsg->GetSipDlgID();
			string strClientUri = cReq.GetDevUri();
			g_tDevUriDialogId[strClientUri] = tDialogId;   //��¼�豸��DIALOGID�Ķ�Ӧ��ϵ

			TASKLOG(DEMO_SERVER, CRITICAL_LEV, "Recv client ACK reply!\n");
			dProcResult = PROCMSG_OK;
		}
		break;
	case IM_C_S_INVITE_BYE_REQ:
		{
			CImMsgReq cReq;
			g_tDevUriDialogId[cReq.GetDevUri()] = INVALID_DIALOG_ID;
			NextState(UnService);
			TASKLOG(DEMO_SERVER, CRITICAL_LEV, "�û�%s�Ͽ�����!\n", cReq.GetDevUri().c_str());
			dProcResult = PROCMSG_DEL;
		}
		break;
	case IM_C_S_DIALOG_MESSAGE_REQ:
		{
			CImMsgReq cReq;
			pcOspSipMsg->GetMsgBody(cReq);

            CEventRsp cRsp;
			cRsp.SetErrorCode(dwErrorCode);
			cRsp.SetSeqNum(cReq.GetSeqNum());
			cRsp.SetSession(cReq.GetSession());
			if (PROCMSG_OK != PostRsp(KDSIP_EVENT_MESSAGE_DIALOG_RSP, pcOspSipMsg->GetSipTransID(), cRsp))
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "����SIP_EV_MESSAGE_RSPʧ��\n");
				return PROCMSG_FAIL;
			}

			CUserData *pcUserData = g_cServerApp.GetAppData().FindUserInfoByUserName(cReq.GetDstUser());//��ȡ�Է�taskָ��

			CImMsgReq cSendReq;
            cSendReq.SetSendContent(cReq.GetSendContent());
			cSendReq.SetSession(pcUserData->GetSessionID());
			m_tDlgId = g_tDevUriDialogId[cReq.GetDstUser()];

			if (PROCMSG_OK != PostInDlgReq(KDSIP_EVENT_MESSAGE_DIALOG_REQ, cSendReq, m_tDlgId))
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "����SIP_EV_MESSAGE_REQʧ��\n");
				return PROCMSG_FAIL;
			}
			dProcResult = PROCMSG_OK;
		}
		break;
	case IM_C_S_DIALOG_MESSAGE_RSP:
		{
			TASKLOG(DEMO_SERVER, EVENT_LEV, "Client recv msg!\n");
			dProcResult = PROCMSG_OK;
		}
		break;
	default:
		break;
	}

	return dProcResult;
}

string OrganizeOnlineInfo(vector<string> &vecOnlineInfo)
{
	string strResultInfo = "";

	for (int i = 0;i < vecOnlineInfo.size();i++)
	{
		strResultInfo += vecOnlineInfo[i];
		strResultInfo += "#";
	}

	return strResultInfo;
}
