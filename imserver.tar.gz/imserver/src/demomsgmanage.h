#ifndef _DEMO_MSG_MANAGE_H
#define	_DEMO_MSG_MANAGE_H

#include <string>
#include "cms/ospext/osptool.h"
#include "system/tinyxml/tinyxml.h"
#include "system/converthelper/toxml.h"
#include "system/converthelper/tostruct.h"
#include "system/converthelper/adpfromstdsettovector.h"
#include "cms/cms_proto.h"
#include "democonf.h"

class CImRegReq : public CEventReq
{
public:
    CImRegReq();

public:
	string& GetDevUri()
	{
		return m_strDevUri;
	}
	void SetDevUri(const string& strDevUri)
	{
		m_strDevUri = strDevUri;
	}
	const string GetUserName() const
	{
		return m_strUserName;
	}
	void SetUserName(const string strUserName)
	{
		m_strUserName = strUserName;
	}
	const string GetPassWord() const
	{
		return m_strPassWord;
	}
	void SetPassWord(const string strPassWord)
	{
		m_strPassWord = strPassWord;
	}
	const string GetSessionID() const
	{
		return m_strSessId;
	}
	void SetSessionID(const string strSessId)
	{
		m_strSessId = strSessId;
	}
	const std::string GetClientURI() const
	{
		return m_tClientURI;
	}
	void SetClientURI(const string tSipURI)
	{
		m_tClientURI = tSipURI;
	}

public:
	const std::string ToXml()const;
	void FromXml(const std::string& xml_string);
	void ToXml(TiXmlDocument& xmlDoc)const;
	void ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const;
	void FromXml(const TiXmlNode& xmlNode);
private:
	string m_strDevUri;
	string m_tClientURI;
	string m_strUserName;
	string m_strPassWord;
	string m_strSessId;
};

class CImRegRsp : public CEventRsp
{
public:
    CImRegRsp();
    virtual ~CImRegRsp();
public:
	void SetRegResultTab(const int nRegResultTab)
	{
		m_nRegResultTab = nRegResultTab;
	}

public:
	const std::string ToXml()const;
	void FromXml(const std::string& xml_string);
	void ToXml(TiXmlDocument& xmlDoc)const;
	void ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const;
	void FromXml(const TiXmlNode& xmlNode);

private:
	int m_nRegResultTab;
};

class CImLoginReq : public CEventReq
{
public:
    CImLoginReq();
public:
	const string GetUserName() const
	{
		return m_strUserName;
	}
	void SetUserName(const string strUserName)
	{
		m_strUserName = strUserName;
	}
	const string GetPassWord() const
	{
		return m_strPassWord;
	}
	void SetPassWord(const string strPassWord)
	{
		m_strPassWord = strPassWord;
	}
	string& GetDevUri()
	{
		return m_strDevUri;
	}
	void SetDevUri(const string& strDevUri)
	{
		m_strDevUri = strDevUri;
	}

public:
	const std::string ToXml()const;
	void FromXml(const std::string& xml_string);
	void ToXml(TiXmlDocument& xmlDoc)const;
	void ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const;
	void FromXml(const TiXmlNode& xmlNode);

private:
	string m_strDevUri;
	string m_strUserName;
	string m_strPassWord;
};

class CImLoginRsp : public CEventRsp
{
public:
    CImLoginRsp();

public:
	string& GetDevUri()
	{
		return devUri;
	}
	void SetLoginResultTab(const int nLoginResultTab)
	{
		m_nLoginResultTab = nLoginResultTab;
	}

public:
	const std::string ToXml()const;
	void FromXml(const std::string& xml_string);
	void ToXml(TiXmlDocument& xmlDoc)const;
	void ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const;
	void FromXml(const TiXmlNode& xmlNode);

private:
	string  devUri;
	int	    m_nLoginResultTab;
};

class CImCheckOutReq : public CEventReq
{
public:
    CImCheckOutReq();

public:
	string& GetDevUri()
	{
		return devUri;
	}

private:
	string devUri;
};

class CImCheckOutRsp : public CEventRsp
{
public:
    CImCheckOutRsp();

public:
	string& GetDevUri()
	{
		return devUri;
	}

	void SetOnlineUserInfo(const string strOnlineUserInfo)
	{
		m_strOnlineUserInfo = strOnlineUserInfo;
	}

	string& GetOnlineUserInfo()
	{
		return m_strOnlineUserInfo;
	}

public:
	const std::string ToXml()const;
	void FromXml(const std::string& xml_string);
	void ToXml(TiXmlDocument& xmlDoc)const;
	void ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const;
	void FromXml(const TiXmlNode& xmlNode);

private:
	string devUri;
	string m_strOnlineUserInfo;
};


class CImMsgReq : public CEventReq
{
public:
    CImMsgReq();
    virtual ~CImMsgReq();

public:
	string& GetDevUri()
	{
		return m_strDevUri;
	}
	string& GetDstUser()
	{
		return m_strDstUser;
	}
	string& GetSendContent()
	{
		return m_strSendContent;
	}
	void SetDevUri(const string& strDevUri)
	{
		m_strDevUri = strDevUri;
	}
	void SetDstUser(const string& strDstUser)
	{
		m_strDstUser = strDstUser;
	}
	void SetSendContent(const string& strSendContent)
	{
		m_strSendContent = strSendContent;
	}

public:
	const std::string ToXml()const;
	void FromXml(const std::string& xml_string);
	void ToXml(TiXmlDocument& xmlDoc)const;
	void ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const;
	void FromXml(const TiXmlNode& xmlNode);
private:
	string m_strDevUri;
	string m_strDstUser;
	string m_strSendContent;
};


class CImDialogMsgReq : public CEventReq
{
public:
    CImDialogMsgReq();

public:
	string& GetDevUri()
	{
		return m_strDevUri;
	}
	string& GetDstUser()
	{
		return m_strDstUser;
	}
	string& GetSendContent()
	{
		return m_strSendContent;
	}
	void SetDevUri(const string& strDevUri)
	{
		m_strDevUri = strDevUri;
	}
	void SetDstUser(const string& strDstUser)
	{
		m_strDstUser = strDstUser;
	}
	void SetSendContent(const string& strSendContent)
	{
		m_strSendContent = strSendContent;
	}

public:
	const std::string ToXml()const;
	void FromXml(const std::string& xml_string);
	void ToXml(TiXmlDocument& xmlDoc)const;
	void ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const;
	void FromXml(const TiXmlNode& xmlNode);
private:
	string m_strDevUri;
	string m_strDstUser;
	string m_strSendContent;
};

class CImNtfReq : public CEventReq
{
public:
    CImNtfReq();
public:
	const string& GetDevURI() const
	{
		return devURI;
	}
	const string& GetDevURI()
	{
		return devURI;
	}
	void SetDevURI(const string& strDevURI)
	{
		devURI = strDevURI;
	}
	const string& GetOnOffStatus() const
	{
		return m_strOnOff;
	}
	string& GetOnOffStatus()
	{
		return m_strOnOff;
	}
	void SetOnOffStatus(const string& tOnOff)
	{
		m_strOnOff = tOnOff;
	}

public:
	const std::string ToXml()const;
	void FromXml(const std::string& xml_string);
	void ToXml(TiXmlDocument& xmlDoc)const;
	void ToXmlWithoutClassNameNode(TiXmlNode& xmlNode)const;
	void FromXml(const TiXmlNode& xmlNode);

private:
	string           devURI;          // uuid@domain
	string           m_strOnOff;      //������״̬
};
#endif
