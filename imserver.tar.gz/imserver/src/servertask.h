#ifndef _SERVER_TASK_H
#define _SERVER_TASK_H

#include "democonf.h"
#include "demomsgmanage.h"
#include "cms/ospext/osptask.h"
#include "imcoreapp.h"

typedef map<string, string> TSendMsgContainer;
typedef map<string, TKDSIP_DIALOG_ID> TDevUriDialogId;
string OrganizeOnlineInfo(vector<string> &vecOnlineInfo);


class CUserInfos;
class CServerTask : public CSipTask
{
public:
	enum 
	{
		UnService = UNKNOWN_STATE + 1,
		Service,
	};

	CServerTask(CInstExt *pcInst);
	virtual ~CServerTask();

	virtual const char* GetObjName() const
	{
		return "CServerTask";
	}

	virtual const char* GetStateName(u32 dwState) const
	{
		switch (dwState)
		{
		case UnService:
			return "UnService";
		case Service:
			return "Service";
		default:
			break;
		}
		return "Unknown State";
	}
    const string& GetUserName()
	{
		return m_strUserName;
	}

	void SetUserName(const string& strUserName)
	{
		m_strUserName = strUserName;
	}
    const string& GetPassWord()
	{
		return m_strPassWord;
	}
	void SetPassWord(const string& strPassWord)
	{
		m_strPassWord = strPassWord;
	}
    const string GetSessionID()
	{
		return m_strSessId;
	}
	void SetSessionID(const string& strSessId)
	{
		m_strSessId = strSessId;
	}
    const TSipURI GetClientURI()
	{
		return m_tClientURI;
	}
	void SetClientURI(const TSipURI &tSipURI)
	{
		m_tClientURI = tSipURI;
	}
	void SetDstUri(const string& strDstUri)
	{
		m_strDstUri = strDstUri;
	}
public:
	virtual void InitStateMachine();
	
	u32 OnWaitLogin(CMessage *const pcMsg);
	u32 OnService(CMessage *const pcMsg);

private:
	TSipURI             m_tClientURI;
	TKDSIP_TRANS_ID     m_tTransId;
	TKDSIP_DIALOG_ID    m_tDlgId;
	string              m_strUserName;
	string              m_strPassWord;
	string              m_strSessId;
	string              m_strDstUri;
};





#endif
