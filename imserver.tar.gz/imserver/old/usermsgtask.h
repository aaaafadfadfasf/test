#ifndef _USER_MSG_TASK_H
#define	_USER_MSG_TASK_H

#include "loginsession.h"
#include "democonf.h"
#include "demomsgmanage.h"
#include "userlogintask.h"

typedef map<string, string> TSendMsgContainer;
typedef map<string, TKDSIP_DIALOG_ID> TDevUriDialogId;
TDevUriDialogId g_tDevUriDialogId;
class CUserMsgTask : public CLoginSession
{
public:
	enum
	{
		UnService = UNKNOWN_STATE + 1,
		Service, 
	};
public:
	CUserMsgTask(CInstExt *pcInst);
	virtual ~CUserMsgTask();

	virtual const char* GetObjName() const
	{
		return "CUserMsgTask";
	}

	const TSipURI GetUserName() const
	{
		return m_tUserName;
	}
	void SetDstUri(const string& strDstUri)
	{
		m_strDstUri = strDstUri;
	}

	virtual const char* GetStateName(u32 dwState) const
	{
		switch (dwState)
		{
		case UnService:
			return "UnService";
		case Service:
			return "Service";
		default:
			break;
		}
		return "Unknown State";
	}

public:
	virtual void InitStateMachine();

public:
	u32 OnUnServiceProc(CMessage *const pcMsg);

	u32	OnServiceProc(CMessage *const pcMsg);

	bool IsService() const
	{
		return (GetState() == Service);
	}

private:
	TSipURI             m_tUserName;
	TSendMsgContainer   m_tSendMsg;
	string              m_strDstUri;
	TKDSIP_TRANS_ID     m_tTransId;
	TKDSIP_DIALOG_ID    m_tDlgId;
};










#endif