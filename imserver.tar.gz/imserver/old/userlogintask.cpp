#include "userlogintask.h"

CUserLoginTask::CUserLoginTask(CInstExt *pcInst) : CLoginSession(pcInst)
{

}

CUserLoginTask::~CUserLoginTask()
{

}

void CUserLoginTask::InitStateMachine()
{
	CStateProc cWaitLoginProc;
	cWaitLoginProc.ProcMsg = (CTask::PFProcMsg)&CUserLoginTask::OnWaitLogin;
	cWaitLoginProc.ProcErrMsg = (CTask::PFProcMsg)&CUserLoginTask::OnWaitLogin;
	cWaitLoginProc.TimerPoll = (CTask::PFTimerPoll)&CUserLoginTask::OnWaitLoginTimer;
	AddRuleProc(WaitLogin, cWaitLoginProc);

	CStateProc cOnServiceProc;
	cOnServiceProc.ProcMsg = (CTask::PFProcMsg)&CUserLoginTask::OnService;
	cOnServiceProc.ProcErrMsg = (CTask::PFProcMsg)&CUserLoginTask::OnService;
	cOnServiceProc.TimerPoll = (CTask::PFTimerPoll)&CUserLoginTask::OnServiceTimer;
	AddRuleProc(Service, cOnServiceProc);

	NextState(WaitLogin);
}

u32 CUserLoginTask::OnWaitLogin(CMessage *const pcMsg)
{
	u32 dProcResult = PROCMSG_FAIL;
	switch (pcMsg->event)
	{
	case IM_C_S_LOGIN_REQ:
		{
			int dwErrorCode = DEMO_SUCCESS;

			COspSipMsg* pcOspSipMsg = (COspSipMsg*)pcMsg->content;
			if (pcOspSipMsg == nullptr)
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "OSP SIP ��ϢΪ��!\n");
				dwErrorCode = ERR_SIP_BODY_EMPTY;
				dProcResult = PROCMSG_DEL;
				return dProcResult;
			}

			CImLoginReq cReq;
			pcOspSipMsg->GetMsgBody(cReq);

			/*��redis���ҵ�ע����Ϣ����֤�Ƿ�ע��,����redis�б�ʶ���û�����*/
			string strPasswd;
			int n_ErrCode = g_redis->Get(cReq.GetUserName(), strPasswd);
			if (n_ErrCode == EC_NOT_EXISTED)
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "��redis��δ���ҵ�%s��ע����Ϣ! ErrCode = %d\n", GetDevUri().c_str(),n_ErrCode);
				dwErrorCode = ERR_REDIS_OPERATE_FAILED;
			}
			if (strPasswd != cReq.GetPassWord())
			{
				dwErrorCode = ERR_USER_LOGIN_FAILED;
				TASKLOG(DEMO_SERVER, ERROR_LEV, "%s�û���½ʧ��", cReq.GetUserName().c_str());
			}
			else
			{
				g_redis->SAdd(ONLINE_INFO,cReq.GetUserName());
			}

			/*����uuid��Ϊsession,������ʶѰ��taskָ��*/
			CUserData *pcUserData = nullptr;
			if (g_cServerApp.GetAppData().FindUserInfoByUserName(cReq.GetUserName()) != nullptr)
			{
				dwErrorCode = ERR_USER_IS_EXIST;
				TASKLOG(DEMO_SERVER, ERROR_LEV, "�û� %s ������\n", cReq.GetUserName().c_str());
			}
			else
			{
				pcUserData = this;
				CUUID cSessionId;
				pcUserData->SetSession(cSessionId);
				g_cServerApp.GetAppData().AddUser(pcUserData);

				//��ʼ����
				SetHBParam(GetDevSipUri());
				NextState(Service);
			}

			CImLoginRsp cRsp;
			cRsp.SetErrorCode(dwErrorCode);
			cRsp.SetSeqNum(cReq.GetSeqNum);
			cRsp.SetSession(pcUserData->GetSession());
			cRsp.SetLoginResultTab(n_ErrCode);
			PostMsgRsp(pcOspSipMsg->GetSipTransID(), cRsp);

			if (dwErrorCode == DEMO_SUCCESS)
			{
				TASKLOG(DEMO_SERVER, CRITICAL_LEV, "%s��½�ɹ�!\n", GetDevUri().c_str());
				dProcResult = PROCMSG_OK;
				NextState(Service);
			}
			else
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "%��½ʧ��!\n", GetDevUri().c_str());
				dProcResult = PROCMSG_DEL;
			}

		}
	break;

	default:
		TASKLOG(DEMO_SERVER, WARNING_LEV, "Recv unkown msg [%s-%d]\n", OspExtEventDesc(pcMsg->event).c_str(), pcMsg->event);
		break;
	}
}

u32 CUserLoginTask::OnWaitLoginTimer()
{
	return TIMERPOLL_DONE;
}

u32 CUserLoginTask::OnService(CMessage *const pcMsg)
{
	u32 dProcResult = PROCMSG_FAIL;
	switch (pcMsg->event)
	{
	case IM_C_S_CHECK_ONLINE_REQ:
		{
			int dwErrorCode = DEMO_SUCCESS;

			COspSipMsg* pcOspSipMsg = (COspSipMsg*)pcMsg->content;
			if (pcOspSipMsg == nullptr)
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "OSP SIP ��ϢΪ��!\n");
				dwErrorCode = ERR_SIP_BODY_EMPTY;
				dProcResult = PROCMSG_DEL;

				return dProcResult;
			}

			CImCheckOutReq cReq;
			pcOspSipMsg->GetMsgBody(cReq);

			/*��redis�л�ȡ��ǰ�����û�*/
			vector<string> vecOnlineInfo;
			g_redis->SMembers(ONLINE_INFO, vecOnlineInfo);
			string strOnlineInfo = OrganizeOnlineInfo(vecOnlineInfo);

			CImCheckOutRsp cRsp;
			cRsp.SetErrorCode(dwErrorCode);
			cRsp.SetSeqNum(cReq.GetSeqNum);
			cRsp.SetSession(cReq.GetSession());
			cRsp.SetOnlineUserInfo(strOnlineInfo);
			PostMsgRsp(pcOspSipMsg->GetSipTransID(), cRsp);

			if (dwErrorCode == DEMO_SUCCESS)
			{
				TASKLOG(DEMO_SERVER, CRITICAL_LEV, "%s��ȡ��ǰ�����û���Ϣ�ɹ�!\n", GetDevUri().c_str());
				dProcResult = PROCMSG_OK;
				NextState(Service);
			}
			else
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "%��ȡ��ǰ�����û���Ϣʧ��!\n", GetDevUri().c_str());
				dProcResult = PROCMSG_DEL;
			}

		}
		break;
	default:
		TASKLOG(DEMO_SERVER, WARNING_LEV, "Recv unkown msg [%s-%d]\n", OspExtEventDesc(pcMsg->event).c_str(), pcMsg->event);
		break;
	}
}

string OrganizeOnlineInfo(vector<string> &vecOnlineInfo)
{
	string strResultInfo = "#";

	for (int i = 0;i < vecOnlineInfo.size();i++)
	{
		strResultInfo += vecOnlineInfo[i];
		strResultInfo += "#";
	}

	return strResultInfo;
}