#include "usersstask.h"


CUserSsTask::CUserSsTask(CInstExt *pcInst) : CSipTask(pcInst)
{

}

CUserSsTask::~CUserSsTask()
{

}

void CUserSsTask::InitStateMachine()
{
	CStateProc cWaitSsProc;
	cWaitSsProc.ProcMsg = (CTask::PFProcMsg)&CUserSsTask::OnWaitSs;
	cWaitSsProc.ProcErrMsg = (CTask::PFProcMsg)&CUserSsTask::OnWaitSs;
	cWaitSsProc.TimerPoll = (CTask::PFTimerPoll)&CUserSsTask::OnWaitSsTimer;
	AddRuleProc(WaitSs, cWaitSsProc);

	CStateProc cNotifyProc;
	cNotifyProc.ProcMsg = (CTask::PFProcMsg)&CUserSsTask::OnNotify;
	cNotifyProc.ProcErrMsg = (CTask::PFProcMsg)&CUserSsTask::OnNotify;
	cNotifyProc.TimerPoll = (CTask::PFTimerPoll)&CUserSsTask::OnNotifyTimer;
	AddRuleProc(Notify, cNotifyProc);

	CStateProc cServiceProc;
	cServiceProc.ProcMsg = (CTask::PFProcMsg)&CUserSsTask::OnService;
	cServiceProc.ProcErrMsg = (CTask::PFProcMsg)&CUserSsTask::OnService;
	cServiceProc.TimerPoll = (CTask::PFTimerPoll)&CUserSsTask::OnServiceTimer;
	AddRuleProc(Service, cWaitSsProc);

	NextState(WaitSs);
}

u32 CUserSsTask::OnWaitSs(CMessage *const pcMsg)
{
	u32 dwRet = PROCMSG_FAIL;

	COspSipMsg* pcOspSipMsg = (COspSipMsg*)pcMsg->content;

	switch (pcOspSipMsg->GetSipEventID())
	{
	case KDSIP_EVENT_SUBSCRIBE_REQ:
		{
			m_tSsDlgId = pcOspSipMsg->GetSipDlgID();

			NextState(Service);

			if (DEMO_SUCCESS == ProcSsReq(pcMsg))				// ���ĳɹ�
			{
				dwRet = PROCMSG_OK;
			}
			else
			{
				dwRet = PROCMSG_DEL;
			}
		}
	break;
	default:
		{
			TASKLOG(DEMO_SERVER, WARNING_LEV, "Receive unknown Msg[%s-%d]\n", OspExtEventDesc(pcMsg->event).c_str(), pcMsg->event);
		}
	break;
	}
	return dwRet;
}

u32 CUserSsTask::OnWaitSsTimer()
{
	return TIMERPOLL_DONE;
}

u32 CUserSsTask::OnNotify(CMessage *const pcMsg)
{
	u32 dwRet = PROCMSG_FAIL;
	switch (pcMsg->event)
	{
	case IM_DEV_OFFLINE_NTF:
		{
			dwRet = PROCMSG_DEL;
		}
		break;
	default:
		{
			COspSipMsg* pcOspSipMsg = (COspSipMsg*)pcMsg->content;
			switch (pcOspSipMsg->GetSipEventID())
			{
			case KDSIP_EVENT_NOTIFY_RSP:
				{
					CEventRsp cNtfRsp;
					pcOspSipMsg->GetMsgBody(cNtfRsp);
					
					if (DEMO_SUCCESS == cNtfRsp.GetErrorCode())
					{
						m_strSendBuf.clear();						//��ջ���

						if (!m_tNtfQueue.empty())					
						{
							PostNtf();
							NextState(Notify);

							dwRet = PROCMSG_OK;
						}
						else
						{
							NextState(Service);

							dwRet = PROCMSG_OK;
						}
					}
				}
			default:
				break;
			}
		}	
		break;
	}
	return dwRet;
}

u32 CUserSsTask::OnNotifyTimer()
{
	return TIMERPOLL_DONE;
}

u32 CUserSsTask::OnService(CMessage *const pcMsg)
{
	u32 dwRet = PROCMSG_FAIL;
	switch (pcMsg->event)
	{
	case IM_DEV_OFFLINE_NTF:
	case OSP_SIP_DISCONNECT:
	{
		dwRet = PROCMSG_DEL;
	}
	break;
	default:
	{
		COspSipMsg* pcOspSipMsg = (COspSipMsg*)pcMsg->content;
		switch (pcOspSipMsg->GetSipEventID())
		{
		case KDSIP_EVENT_UNSUBSCRIBE_REQ:
			{
				ProcUnSsReq(pcMsg);
				dwRet = PROCMSG_DEL;
			}
			break;
		default:
			break;
		}
	}
	break;
	}

}

u32 CUserSsTask::OnServiceTimer()
{

}


u32 CUserSsTask::ProcSsReq(CMessage *const pcMsg)
{
	COspSipMsg *pcOspSipMsg = (COspSipMsg *)pcMsg->content;

	CImSsReq cReq;
	pcOspSipMsg->GetMsgBody(cReq);

	SetSession(cReq.GetSession());
	SetUserUri(cReq.GetUserUri());

	TSipURI tDevUri(cReq.GetDevUri());
	TASKLOG(DEMO_SERVER, EVENT_LEV, "�û�[%s]����PU[%s]��Ϣ",
		GetUserUri().c_str(), cReq.GetDevUri().c_str());

	CImSsRsp cRsp;
	cRsp.SetHeadFromReq(cReq);

	m_mapSubTaskList[GetTaskNO()] = ON_OFF_SUB_TYPE;
	m_mapSubDevList[cReq.GetDevUri()] = ON_OFF_SUB_TYPE;

	//���ͳ�ʼ��Ϣ
	PostRsp(KDSIP_EVENT_SUBSCRIBE_RSP, pcOspSipMsg->GetSipTransID(), cRsp);
	if (DEMO_SUCCESS == cRsp.GetErrorCode())
	{
		PublishInitialNotify(m_mapSubDevList);
	}
}

u32 CUserSsTask::ProcUnSsReq(CMessage * const pcMsg)
{
	COspSipMsg *pcOspSipMsg = (COspSipMsg *)pcMsg->content;
	CImUnSsReq cReq;
	pcOspSipMsg->GetMsgBody(cReq);

	CImUnSsRsp cRsp;
	cRsp.SetHeadFromReq(cReq);

	PostRsp(KDSIP_EVENT_UNSUBSCRIBE_RSP, pcOspSipMsg->GetSipTransID(), cRsp);
}

void CUserSsTask::PublishInitialNotify(const TSsDevList &tSsDevList)
{
	for (auto it = tSsDevList.begin();it != tSsDevList.end();it++)
	{
		CEventReq cReq;
		PrePostNotify(it->first, it->second, cReq);
	}
}


void CUserSsTask::PrePostNotify(const string &strDevId, const TSsType &tSsType, const CEventReq &cNtfReq)
{
	TNtfElement tNtfElement;
	tNtfElement.tSsType = tSsType;
	if (!cNtfReq.GetEventStr().empty())
	{
		tNtfElement.bDirectSend = true;
		tNtfElement.cContent.push_back(cNtfReq.ToXml());
	}
	else
	{
		tNtfElement.bDirectSend = false;
		tNtfElement.strExtra1 = strDevId;
		tNtfElement.strExtra2 = cNtfReq.GetSession();
	}

	m_tNtfQueue.push(tNtfElement);
	if (GetState() != Notify)
	{
		PostNtf();
		NextState(Notify);
	}
}

void CUserSsTask::PostNtf()
{
	if (m_strSendBuf.empty())
	{
		if (!m_tNtfQueue.empty())
		{
			TNtfElement &tNtfElement = m_tNtfQueue.front();
			
			bool bDirectSend = tNtfElement.bDirectSend;
			if (!bDirectSend)
			{
				GetNtfContent(tNtfElement);
			}
			
			if (!tNtfElement.cContent.empty())
			{
				m_strSendBuf = tNtfElement.cContent.front();
				tNtfElement.cContent.pop_front();
			}
		}
		else
		{
			return;
		}
	}

	if (!m_strSendBuf.empty())
	{
		PostInDlgReq(KDSIP_EVENT_NOTIFY_REQ, m_strSendBuf, m_tSsDlgId);
	}
	else
	{
		PostNtf();
	}
}

void CUserSsTask::GetNtfContent(TNtfElement &tElement)
{
	if (!tElement.bDirectSend && tElement.cContent.empty())
	{
		if (tElement.tSsType == ON_OFF_SUB_TYPE)
		{
			string strDevStatus = GetDevStatus(tElement.strExtra1);

			CImNtfReq cNtfReq;
			cNtfReq.SetDevURI(tElement.strExtra1);
			cNtfReq.SetSession(tElement.strExtra2);
			cNtfReq.SetOnOffStatus(strDevStatus);
			tElement.cContent.push_back(cNtfReq.ToXml());
		}
	}

	tElement.bDirectSend = true;
}

const string& CUserSsTask::GetDevStatus(const string &strDevUri)
{
	if (EC_OK == g_redis->SisMember(ONLINE_INFO, strDevUri))
	{
		return "on";
	}
	return "off";
}