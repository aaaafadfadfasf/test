#ifndef _USER_LOGIN_TASK_H
#define	_USER_LOGIN_TASK_H

#include "loginsession.h"
#include "democonf.h"
#include "demomsgmanage.h"
#include "servertask.h"


class CUserLoginTask : public CLoginSession
{
public:
	enum
	{
		WaitLogin = UNKNOWN_STATE + 1,
		Service,
	};
public:
	CUserLoginTask(CInstExt *pcInst);
	virtual ~CUserLoginTask();

	virtual const char* GetObjName() const
	{
		return "CUserLoginTask";
	}

	const TSipURI GetUserName() const
	{
		return m_tUserName;
	}

	virtual const char* GetStateName(u32 dwState) const
	{
		switch (dwState)
		{
		case WaitLogin:
			return "WaitLogin";
		case Service:
			return "Service";
		default:
			break;
		}
		return "Unknown State";
	}

public:
	virtual void InitStateMachine();

public:
	u32 OnWaitLogin(CMessage *const pcMsg);
	u32 OnWaitLoginTimer();

	u32	OnService(CMessage *const pcMsg);
	u32 OnServiceTimer();

	bool IsService() const
	{
		return (GetState() == Service);
	}

private:
	TSipURI m_tUserName;
};

typedef CServerTask CUserData;
typedef CUserData *PCUerData;





#endif
