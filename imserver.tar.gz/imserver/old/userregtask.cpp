#include "userregtask.h"
#include "userinfo.h"

CUserRegTask::CUserRegTask(CInstExt *pcInst) :CLoginSession(pcInst)
{

}
CUserRegTask::~CUserRegTask()
{

}

void CUserRegTask::InitStateMachine()
{
	CStateProc cWaitRegProc;
	cWaitRegProc.ProcMsg = (CTask::PFProcMsg)&CUserRegTask::OnWaitReg;
	cWaitRegProc.ProcErrMsg = (CTask::PFProcMsg)&CUserRegTask::OnWaitReg;
	cWaitRegProc.TimerPoll = (CTask::PFTimerPoll)&CUserRegTask::OnWaitRegTimer;
	AddRuleProc(WaitReg, cWaitRegProc);

	NextState(WaitReg);
}

u32 CUserRegTask::OnWaitReg(CMessage *const pcMsg)
{
	u32 dProcResult = PROCMSG_FAIL;
	switch (pcMsg->event)
	{
	case IM_C_S_REG_REQ:
		{
			int dwErrorCode = DEMO_SUCCESS;

			COspSipMsg* pcOspSipMsg = (COspSipMsg*)pcMsg->content;
			if (pcOspSipMsg == nullptr)
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "OSP SIP ��ϢΪ��!\n");
				dwErrorCode = ERR_SIP_BODY_EMPTY;
				dProcResult = PROCMSG_DEL;
				return dProcResult;
			}

			CImRegReq cReq;
			pcOspSipMsg->GetMsgBody(cReq);
			
			/*��ע����Ϣ��DevUri������redis������֤�Ƿ���ע��*/
			if (EC_NOT_EXISTED == g_redis->IsKeyExists(cReq.GetUserName()))
			{
				g_redis->Set(cReq.GetUserName(), cReq.GetPassWord());
			}
			else
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "ע����Ϣ%sʧ��", cReq.GetUserName().c_str());
				dwErrorCode = ERR_REDIS_OPERATE_FAILED;
			}

			CImRegRsp cRsp;
			cRsp.SetErrorCode(dwErrorCode);
			cRsp.SetSeqNum(cReq.GetSeqNum);
			cRsp.SetSession(GetDevUri());
			cRsp.SetRegResultTab(dwErrorCode);
			PostMsgRsp(pcOspSipMsg->GetSipTransID(), cRsp);

			if (dwErrorCode == DEMO_SUCCESS)
			{
				TASKLOG(DEMO_SERVER, CRITICAL_LEV, "%sע��ɹ�!\n", GetDevUri().c_str());
				dProcResult = PROCMSG_OK;
			}
			else
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "%sע��ʧ��!\n", GetDevUri().c_str());
				dProcResult = PROCMSG_DEL;
			}
		}
		break;

	default:
		TASKLOG(DEMO_SERVER, WARNING_LEV, "Recv unkown msg [%s-%d]\n", OspExtEventDesc(pcMsg->event).c_str(), pcMsg->event);
		break;
	}
}

u32 CUserRegTask::OnWaitRegTimer()
{
	return TIMERPOLL_DONE;
}

