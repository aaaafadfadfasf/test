#include "usermsgtask.h"


CUserMsgTask::CUserMsgTask(CInstExt *pcInst) : CLoginSession(pcInst)
{

}

CUserMsgTask::~CUserMsgTask()
{

}

void CUserMsgTask::InitStateMachine()
{
	CStateProc cOnUnServiceProc;
	cOnUnServiceProc.ProcMsg = (CTask::PFProcMsg)&CUserMsgTask::OnUnServiceProc;
	cOnUnServiceProc.ProcErrMsg = (CTask::PFProcMsg)&CUserMsgTask::OnUnServiceProc;
	AddRuleProc(UnService, cOnUnServiceProc);

	CStateProc cOnServiceProc;
	cOnServiceProc.ProcMsg = (CTask::PFProcMsg)&CUserMsgTask::OnServiceProc;
	cOnServiceProc.ProcErrMsg = (CTask::PFProcMsg)&CUserMsgTask::OnServiceProc;
	AddRuleProc(Service, cOnServiceProc);

	NextState(UnService);
}

u32 CUserMsgTask::OnUnServiceProc(CMessage *const pcMsg)
{
	u32 dProcResult = PROCMSG_FAIL;

	int dwErrorCode = DEMO_SUCCESS;
	COspSipMsg* pcOspSipMsg = (COspSipMsg*)pcMsg->content;
	if (pcOspSipMsg == nullptr)
	{
		TASKLOG(DEMO_SERVER, ERROR_LEV, "OSP SIP ��ϢΪ��!\n");
		dwErrorCode = ERR_SIP_BODY_EMPTY;
		dProcResult = PROCMSG_DEL;
		return dProcResult;
	}
	switch (pcMsg->event)
	{
	case IM_C_S_INVITE_REQ:
		{
			CEventReq cReq;
			pcOspSipMsg->GetMsgBody(cReq);

			CEventRsp cRsp;
			cRsp.SetSession(cReq.GetSession());
			cRsp.SetErrorCode(dwErrorCode);
			cRsp.SetEvent("IM_S_C_INVITE_RSP");
			cRsp.SetSeqNum(cReq.GetSeqNum);

			PostRsp(KDSIP_EVENT_INVITE_RSP, pcOspSipMsg->GetSipTransID(), cRsp);
			NextState(Service);
		}
		break;
	case IM_C_S_INVITE_BYE_REQ:
		{
			CEventReq cReq;
			pcOspSipMsg->GetMsgBody(cReq);

			CEventRsp cRsp;
			cRsp.SetSession(cReq.GetSession());
			cRsp.SetErrorCode(ERR_UNINVITE);
			cRsp.SetEvent("IM_S_C_INVITE_BYE_RSP");
			cRsp.SetSeqNum(cReq.GetSeqNum());
			
			PostRsp(KDSIP_EVENT_INVITE_BYE_RSP, pcOspSipMsg->GetSipTransID(), cRsp);

			//ɾ���û�
			g_cServerApp.GetAppData().DelUser(this);
		}
		break;
	default:
		break;
	}
	return PROCMSG_OK;
}

u32 CUserMsgTask::OnServiceProc(CMessage *const pcMsg)
{
	u32 dProcResult = PROCMSG_FAIL;

	int dwErrorCode = DEMO_SUCCESS;
	COspSipMsg* pcOspSipMsg = (COspSipMsg*)pcMsg->content;
	if (pcOspSipMsg == nullptr)
	{
		TASKLOG(DEMO_SERVER, ERROR_LEV, "OSP SIP ��ϢΪ��!\n");
		dwErrorCode = ERR_SIP_BODY_EMPTY;
		dProcResult = PROCMSG_DEL;
		return dProcResult;
	}
	switch (pcMsg->event)
	{
	case IM_C_S_INVITE_ACK:
		{	
			CImMsgReq cReq;
			TKDSIP_DIALOG_ID tDialogId = pcOspSipMsg->GetSipDlgID();
			string strClientUri = cReq.GetDevUri();
			g_tDevUriDialogId[strClientUri] = tDialogId;   //��¼�豸��DIALOGID�Ķ�Ӧ��ϵ

			TASKLOG(DEMO_SERVER, CRITICAL_LEV, "Recv client ACK reply!\n");
			dProcResult = PROCMSG_OK;
		}
		break;
	case IM_C_S_DIALOG_MESSAGE_REQ:
		{
			CImMsgReq cReq;
			pcOspSipMsg->GetMsgBody(cReq);

			CImMsgRsp cRsp;
			cRsp.SetErrorCode(dwErrorCode);
			cRsp.SetSeqNum(cReq.GetSeqNum());
			cRsp.SetSession(cReq.GetSession());
			if (PROCMSG_OK != PostRsp(KDSIP_EVENT_MESSAGE_DIALOG_RSP, pcOspSipMsg->GetSipTransID(), cRsp))
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "����SIP_EV_MESSAGE_RSPʧ��\n");
				return PROCMSG_FAIL;
			}

			CUserData *pcUserData = g_cServerApp.GetAppData().FindUserInfoByUserName(cReq.GetDstUser());//��ȡ�Է�taskָ��

			CImMsgReq cSendReq;
			cSendReq.SetSendContent(cReq.GetSendContent);
			cSendReq.SetSession(pcUserData->GetSession());
			m_tDlgId = g_tDevUriDialogId[cReq.GetDstUser()];

			if (PROCMSG_OK != PostInDlgReq(KDSIP_EVENT_MESSAGE_DIALOG_REQ, cSendReq, m_tDlgId))
			{
				TASKLOG(DEMO_SERVER, ERROR_LEV, "����SIP_EV_MESSAGE_REQʧ��\n");
				return PROCMSG_FAIL;
			}
			dProcResult = PROCMSG_OK;
		}
		break;
	case IM_C_S_DIALOG_MESSAGE_RSP:
		{
			TASKLOG(DEMO_SERVER, EVENT_LEV, "Client recv msg!\n");
			dProcResult = PROCMSG_OK;
		}
		break;
	case IM_C_S_INVITE_BYE_REQ:
		{
			CImMsgReq cReq;
			g_tDevUriDialogId[cReq.GetDevUri()] = INVALID_DIALOG_ID;
			NextState(UnService);
 			TASKLOG(DEMO_SERVER, CRITICAL_LEV, "�û�%s�Ͽ�����!\n", GetDevUri().c_str());
			dProcResult = PROCMSG_DEL;
		}
		break;
	default:
		TASKLOG(DEMO_SERVER, WARNING_LEV, "Recv unkown msg [%s-%d]\n", OspExtEventDesc(pcMsg->event).c_str(), pcMsg->event);
		break;
	}
	return dProcResult;
}