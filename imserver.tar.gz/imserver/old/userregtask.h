#ifndef _USER_REG_TASK_H
#define _USER_REG_TASK_H

#include "loginsession.h"
#include "democonf.h"
#include "demomsgmanage.h"
#include "cms/ospext/osptask.h"

class CUserRegTask : public CLoginSession
{
public:
	enum
	{
		WaitReg = UNKNOWN_STATE + 1,
		Service,
	};

public:
	CUserRegTask(CInstExt *pcInst);
	virtual ~CUserRegTask();

public:
	virtual const char* GetObjName() const
	{
		return "CUserRegTask";
	}

	virtual const char* GetStateName(u32 dwState) const
	{
		switch (dwState)
		{
		case WaitReg:
			return "WaitReg";
		default:
			break;
		}
		return "Unknown State";
	}
	const string GetUserName() const
	{
		return m_strUserName;
	}
	void SetUserName(const string strUserName)
	{
		m_strUserName = strUserName;
	}
	const string GetPassWord() const
	{
		return m_strPassWord;
	}
	void SetPassWord(const string strPassWord)
	{
		m_strPassWord = strPassWord;
	}
	const string GetSessionID() const
	{
		return m_strSessId;
	}
	void SetSessionID(const string strSessId)
	{
		m_strSessId = strSessId;
	}
	const TSipURI GetClientURI() const
	{
		return m_tClientURI;
	}
	void SetClientURI(const TSipURI &tSipURI)
	{
		m_tClientURI = tSipURI;
	}
	

public:
	virtual void InitStateMachine();

public:
	u32 OnWaitReg(CMessage *const pcMsg);
	u32 OnWaitRegTimer();

	bool IsService() const
	{
		return (GetState() == Service);
	}

private:
	TSipURI m_tClientURI;
	string m_strUserName;
	string m_strPassWord;
	string m_strSessId;
	
};





#endif